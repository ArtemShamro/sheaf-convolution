import networkx as nx
import torch
from torch_geometric.datasets import Planetoid
from torch_geometric.utils import to_networkx
import torch_geometric.transforms as T
from typing import Tuple
from utils import get_mask_edge_prediction
import numpy as np
import torch.nn.functional as F
from tqdm import tqdm


def generate_dataset(name: str = 'Simple', task: str = 'classification', test_size: float = 0.2,
                     ndata: int = 1000, dimx: int = 10) -> nx.Graph:
    """
    task - 'classification' / 'edges_prediction'
    """
    match name:
        case 'Simple':
            return generate_simple_data()
        case 'Synthetic':
            return generate_synthetic_data(ndata, dimx, task, test_size)
        case 'Cora':
            return generate_cora_data(task, test_size)
        case _:
            raise ValueError(f'Unknown data name: {name}')


def generate_simple_data():
    G_sim = nx.erdos_renyi_graph(n=4, p=0.5)
    data_x, data_y = generate_features_and_labels(4, 2, num_classes=2)
    mask = torch.ones_like(torch.tensor(nx.to_numpy_array(G_sim))).bool()
    return G_sim, data_x, data_y, mask, mask


def generate_synthetic_data(ndata, dimx, task, test_size=0.2, s_threshold=0.2, nproj=4):
    data_x, _, adj_mat, _ = generate_graph(
        ndata, dimx, s_threshold, nproj, nvec=2)
    adj_mat -= np.diag(np.ones(ndata))
    G = nx.from_numpy_array(adj_mat)
    _, data_y = generate_features_and_labels(ndata, 1, num_classes=1)
    # if task == 'classification':
    #     return G, graph.x, graph.y, ~graph.test_mask, graph.test_mask
    train_mask, test_mask = get_mask_edge_prediction(G, test_size=test_size)
    return G, data_x, data_y, train_mask, test_mask


def generate_data(ndata, dimy):
    ydata = torch.normal(0.0, 1.0, (ndata, dimy))
    return F.normalize(ydata, dim=1).numpy()


def perform_orthogonalization(vmat):
    """ Gram–Schmidt process for 2 #nvec random vectors"""
    smat = vmat.copy()
    nvec, dimy = smat.shape
    for idx0 in range(nvec):
        for idx1 in range(idx0):
            smat[idx0, :] = smat[idx0, :] - \
                np.dot(smat[idx0, :], smat[idx1, :]) * smat[idx1, :]
        smat[idx0, :] = smat[idx0, :] / \
            np.sqrt(np.dot(smat[idx0, :], smat[idx0, :]))
    return smat


def generate_projection_matrix(nvec, dimx):
    return perform_orthogonalization(np.random.normal(0.0, 1.0, (nvec, dimx)))


def compute_projection(xdata, smat):
    return np.dot(xdata, np.dot(np.transpose(smat), smat))


def compute_distance_matrix(ydata):
    ndata, dimy = ydata.shape
    smat = np.zeros((ndata, ndata))
    for idx0 in range(ndata):
        for idx1 in range(ndata):
            dy = ydata[idx1, :] - ydata[idx0, :]
            smat[idx0, idx1] = np.sqrt(np.sum(dy * dy))
    return smat


def generate_graph(ndata, dimx, s_threshold=0.2, nproj=4, nvec=2):
    print('Generating graph...')
    xdata = generate_data(ndata, dimx)

    # adjacency mat
    wmat = np.zeros((ndata, ndata))

    proj_mat_data = np.zeros((nproj, nvec, dimx))

    xproj = np.zeros((nproj, ndata, dimx))

    for idx in range(nproj):
        proj_mat_data[idx, :, :] = generate_projection_matrix(nvec, dimx)
        xproj[idx, :, :] = compute_projection(xdata, proj_mat_data[idx, :, :])

    for idx0 in tqdm(range(ndata)):
        for idx1 in range(ndata):
            for idx in range(nproj):
                dx = xproj[idx, idx1, :] - xproj[idx, idx0, :]
                s = np.sqrt(np.sum(dx * dx))
                if s < s_threshold:
                    wmat[idx0, idx1] = 1.0

    return (torch.from_numpy(xdata).float(),
            torch.from_numpy(proj_mat_data).float(),
            wmat,
            torch.from_numpy(xproj).float())


def generate_cora_data(task: str = 'classification', test_size: float = 0.2) -> Tuple[nx.Graph, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    PL = Planetoid(root="./datasets/Planetoid/", name="Cora",
                   transform=T.NormalizeFeatures())
    graph = PL[0]
    G = to_networkx(graph, to_undirected=True)
    if task == 'classification':
        return G, graph.x, graph.y, ~graph.test_mask, graph.test_mask
    train_mask, test_mask = get_mask_edge_prediction(G, test_size=test_size)
    return G, graph.x, graph.y, train_mask, test_mask


def generate_features_and_labels(num_nodes, dim_features, num_classes=2):
    data_x = torch.rand(size=(num_nodes, dim_features),
                        dtype=torch.float) * 2 - 1
    data_x = torch.nn.functional.normalize(data_x, dim=1)
    data_y = torch.randint(0, num_classes, size=(num_nodes, 1))
    return data_x, data_y
